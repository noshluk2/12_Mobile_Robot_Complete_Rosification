#!/usr/bin/python
import sys
import rospy
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from math import pow, atan2, sqrt


## PUBLISHER + SUBSCRIBER

# THIS code is not working properly and left as it is with intention
        # YOU have to make a bit of change to code and it will start working
turtleBot_pose = Pose() 


def calculate_GTG( data):
        
        turtleBot_pose.x = round(data.x, 4)
        turtleBot_pose.y = round(data.y, 4)
        turtleBot_pose.theta = data.theta
def looping_until_goal_reached():
        rospy.init_node('gtg', anonymous=True)
        get_pose = rospy.Subscriber('/turtle1/pose',Pose,calculate_GTG) # x y position for turtle
        command_velocity = rospy.Publisher('/turtle1/cmd_vel',Twist, queue_size=10)
        cmd_vel = Twist()
        rate = rospy.Rate(10)
        remaining_distance=1.1;
        while remaining_distance >= 0.01:
            remaining_distance = sqrt(pow((goal_coordinate_x - turtleBot_pose.x), 2) +  pow((goal_coordinate_y - turtleBot_pose.y), 2))
            angle_to_goal = atan2(goal_coordinate_y - turtleBot_pose.y, goal_coordinate_x - turtleBot_pose.x)
            angle_difference = angle_to_goal - turtleBot_pose.theta # to calculate diff curr and target 
            cmd_vel.linear.x = remaining_distance 
            cmd_vel.angular.z = angle_difference

            command_velocity.publish(cmd_vel)
            rate.sleep()
            print(remaining_distance)
            
        cmd_vel.linear.x = 0
        cmd_vel.angular.z = 0
        command_velocity.publish(cmd_vel)
        rospy.spin()

if __name__ == '__main__':
    goal_coordinate_x = int(sys.argv[1])
    goal_coordinate_y = int(sys.argv[2])  
    looping_until_goal_reached()
