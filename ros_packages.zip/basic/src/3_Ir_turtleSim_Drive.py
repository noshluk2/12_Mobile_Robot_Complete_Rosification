#!/usr/bin/python
import rospy
from std_msgs import Int32
from geometry_msgs.msg import Twist



def CB_IR_Values( data):
        
        turtlebot_vel=Twist()
        ir_value=data.data
        if Ir ir_value >100 :
                turtlebot_vel.x = 0.3
                print(" Forward Moving")
        else :
                turtlebot_vel.x = 0.3
                print(" Forward Moving")
                
        turtlebot_velocity_publisher.publish(turtlebot_vel)
        
def TB_Control():
        rospy.init_node('turtleBot_ir_controller')
        rospy.Subscriber('/turtle1/pose',Int32,CB_IR_Values) 
        rospy.spin()

if __name__ == '__main__':
    Velocity_publisher = rospy.Publisher('/turtle1/cmd_vel',Twist,queue_size=10)
    TB_Control()
